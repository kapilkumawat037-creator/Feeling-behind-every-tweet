import { storage } from "./storage";

async function seed() {
  console.log("Seeding database...");
  const analyses = await storage.getAnalyses();
  if (analyses.length === 0) {
    await storage.createAnalysis({
      text: "I just had the most amazing coffee! Best start to the day. ☕️✨",
      emotion: "Positive",
      confidenceScore: 95
    });
    
    await storage.createAnalysis({
      text: "My flight got delayed by 4 hours and I missed my connection. Absolutely terrible service.",
      emotion: "Negative",
      confidenceScore: 92
    });
    
    await storage.createAnalysis({
      text: "The new software update drops next Tuesday at 10 AM.",
      emotion: "Neutral",
      confidenceScore: 88
    });
    console.log("Database seeded successfully.");
  } else {
    console.log("Database already seeded.");
  }
}

seed().catch(console.error).then(() => process.exit(0));
