import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.analyses.list.path, async (req, res) => {
    try {
      const analyses = await storage.getAnalyses();
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.analyses.create.path, async (req, res) => {
    try {
      const input = api.analyses.create.input.parse(req.body);
      
      // Analyze sentiment using OpenAI
      const prompt = `Analyze the sentiment of the following tweet.
Respond with a JSON object containing exactly two keys:
- "emotion": string (must be exactly one of "Positive", "Negative", or "Neutral")
- "confidenceScore": number (an integer between 0 and 100)

Tweet:
"""
${input.text}
"""`;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const resultText = response.choices[0]?.message?.content || "{}";
      const resultObj = JSON.parse(resultText);

      const emotion = ["Positive", "Negative", "Neutral"].includes(resultObj.emotion) 
        ? resultObj.emotion 
        : "Neutral";
      const confidenceScore = typeof resultObj.confidenceScore === "number" 
        ? Math.min(Math.max(Math.round(resultObj.confidenceScore), 0), 100)
        : 50;

      // Save to database
      const analysis = await storage.createAnalysis({
        text: input.text,
        emotion,
        confidenceScore,
      });

      res.status(201).json(analysis);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join("."),
        });
      }
      console.error("Analysis error:", err);
      res.status(500).json({ message: "Failed to analyze tweet" });
    }
  });

  return httpServer;
}
