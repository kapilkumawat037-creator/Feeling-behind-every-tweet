## Packages
framer-motion | Page transitions and complex floating animations for the hero section
date-fns | Formatting timestamps for the history dashboard

## Notes
The application relies on the `@shared/routes` and `@shared/schema` for API contracts.
The UI is strictly dark-themed with glassmorphism to fulfill the requested aesthetic.
