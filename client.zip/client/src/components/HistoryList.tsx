import { useAnalyses } from "@/hooks/use-analyses";
import { Card } from "@/components/ui/card";
import { format } from "date-fns";
import { Smile, Frown, Meh, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

export function HistoryList() {
  const { data: analyses, isLoading } = useAnalyses();

  const getEmotionDetails = (emotion: string) => {
    switch (emotion) {
      case 'Positive': return { color: 'text-emerald-400', bg: 'bg-emerald-500/10', icon: Smile };
      case 'Negative': return { color: 'text-rose-400', bg: 'bg-rose-500/10', icon: Frown };
      default: return { color: 'text-slate-400', bg: 'bg-slate-500/10', icon: Meh };
    }
  };

  if (isLoading) {
    return (
      <div className="w-full max-w-5xl mx-auto px-4 mt-20 space-y-4">
        <h2 className="text-2xl font-display font-bold flex items-center gap-2 mb-6">
          <Clock className="text-primary" /> Analysis History
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <Skeleton key={i} className="h-40 rounded-2xl glass-panel opacity-50" />
          ))}
        </div>
      </div>
    );
  }

  if (!analyses || analyses.length === 0) {
    return null; // Don't show history section if empty to keep UI clean
  }

  return (
    <div className="w-full max-w-5xl mx-auto px-4 mt-24 mb-20">
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-display font-bold flex items-center gap-3 text-foreground/90">
          <span className="p-2 rounded-lg bg-primary/10 text-primary">
            <Clock className="w-5 h-5" />
          </span>
          Recent Analyses
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {analyses.slice(0, 9).map((analysis, index) => { // Show max 9 items for layout
          const { color, bg, icon: Icon } = getEmotionDetails(analysis.emotion);
          
          return (
            <motion.div
              key={analysis.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
            >
              <Card className="glass-panel glass-panel-hover p-5 h-full flex flex-col justify-between group">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`flex items-center gap-2 px-3 py-1 rounded-full ${bg} border border-white/5`}>
                      <Icon className={`w-4 h-4 ${color}`} />
                      <span className={`text-xs font-bold uppercase tracking-wider ${color}`}>
                        {analysis.emotion}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground font-medium">
                      {analysis.confidenceScore}% Conf.
                    </span>
                  </div>
                  
                  <p className="text-sm text-foreground/80 line-clamp-3 leading-relaxed">
                    {analysis.text}
                  </p>
                </div>
                
                <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-muted-foreground">
                  <span>ID: #{analysis.id}</span>
                  <span>{format(analysis.createdAt, "MMM d, yyyy")}</span>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
