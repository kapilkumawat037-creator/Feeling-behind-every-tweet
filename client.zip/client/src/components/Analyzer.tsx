import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useCreateAnalysis } from "@/hooks/use-analyses";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Loader2, Send, Copy, CheckCircle2, AlertCircle, Smile, Frown, Meh } from "lucide-react";
import type { AnalysisResponse } from "@shared/routes";

export function Analyzer() {
  const [text, setText] = useState("");
  const [copied, setCopied] = useState(false);
  const [currentResult, setCurrentResult] = useState<AnalysisResponse | null>(null);
  
  const { mutate: analyze, isPending } = useCreateAnalysis();

  const handleAnalyze = () => {
    if (!text.trim()) return;
    analyze({ text }, {
      onSuccess: (data) => setCurrentResult(data)
    });
  };

  const copyToClipboard = () => {
    if (!currentResult) return;
    const textToCopy = `Sentiment: ${currentResult.emotion} (${currentResult.confidenceScore}% confidence)\nText: "${currentResult.text}"`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getEmotionConfig = (emotion: string) => {
    switch (emotion) {
      case 'Positive':
        return {
          color: 'text-emerald-400',
          bg: 'bg-emerald-500/10',
          border: 'border-emerald-500/30',
          progress: 'bg-emerald-500',
          icon: <Smile className="w-12 h-12 text-emerald-400" />
        };
      case 'Negative':
        return {
          color: 'text-rose-400',
          bg: 'bg-rose-500/10',
          border: 'border-rose-500/30',
          progress: 'bg-rose-500',
          icon: <Frown className="w-12 h-12 text-rose-400" />
        };
      default:
        return {
          color: 'text-slate-400',
          bg: 'bg-slate-500/10',
          border: 'border-slate-500/30',
          progress: 'bg-slate-500',
          icon: <Meh className="w-12 h-12 text-slate-400" />
        };
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 space-y-8">
      {/* Input Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Card className="glass-panel p-2 overflow-hidden border-white/10 group focus-within:border-primary/50 transition-colors duration-500">
          <div className="relative">
            <Textarea 
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Paste a tweet or type something here..."
              className="min-h-[160px] resize-none bg-transparent border-0 focus-visible:ring-0 text-lg p-6 placeholder:text-muted-foreground/60"
              maxLength={1000}
            />
            <div className="absolute bottom-4 right-4 flex items-center gap-4">
              <span className="text-sm font-medium text-muted-foreground/60">
                {text.length}/1000
              </span>
              <Button 
                onClick={handleAnalyze} 
                disabled={isPending || !text.trim()}
                className="bg-primary hover:bg-primary/90 text-white rounded-full px-6 py-6 font-semibold shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all hover:-translate-y-0.5"
              >
                {isPending ? (
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                ) : (
                  <Send className="w-5 h-5 mr-2" />
                )}
                {isPending ? "Analyzing..." : "Analyze Emotion"}
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Result Section */}
      <AnimatePresence mode="wait">
        {currentResult && (
          <motion.div
            key="result"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
          >
            {(() => {
              const config = getEmotionConfig(currentResult.emotion);
              return (
                <Card className={`glass-panel p-8 border ${config.border} relative overflow-hidden`}>
                  {/* Decorative background glow based on emotion */}
                  <div className={`absolute -inset-20 opacity-20 blur-3xl rounded-full ${config.bg} pointer-events-none`} />
                  
                  <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
                    
                    {/* Icon & Primary Label */}
                    <div className="flex flex-col items-center justify-center space-y-4 min-w-[150px]">
                      <div className={`p-4 rounded-full ${config.bg} shadow-xl backdrop-blur-md border ${config.border}`}>
                        {config.icon}
                      </div>
                      <h3 className={`text-3xl font-display font-bold ${config.color}`}>
                        {currentResult.emotion}
                      </h3>
                    </div>

                    {/* Details */}
                    <div className="flex-1 w-full space-y-6">
                      <div>
                        <div className="flex justify-between items-end mb-2">
                          <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Confidence Score</span>
                          <span className={`text-xl font-bold ${config.color}`}>{currentResult.confidenceScore}%</span>
                        </div>
                        {/* Custom Progress Bar for exact color matching */}
                        <div className="h-3 w-full bg-background/50 rounded-full overflow-hidden border border-white/5 shadow-inner">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${currentResult.confidenceScore}%` }}
                            transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
                            className={`h-full ${config.progress} shadow-[0_0_10px_rgba(0,0,0,0.5)]`}
                          />
                        </div>
                      </div>

                      <div className="p-4 rounded-xl bg-background/40 border border-white/5 text-muted-foreground italic relative">
                        <div className="absolute top-2 left-2 text-white/10 text-4xl font-serif">"</div>
                        <p className="relative z-10 line-clamp-3 text-sm pt-2">{currentResult.text}</p>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex md:flex-col gap-3">
                      <Button 
                        variant="outline" 
                        size="icon"
                        className="rounded-full h-12 w-12 glass-panel glass-panel-hover border-white/10"
                        onClick={copyToClipboard}
                        title="Copy Result"
                      >
                        {copied ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <Copy className="w-5 h-5" />}
                      </Button>
                    </div>

                  </div>
                </Card>
              );
            })()}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
