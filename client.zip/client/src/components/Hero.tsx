import { motion } from "framer-motion";
import { Twitter, Sparkles, MessageCircleHeart, Frown, Meh } from "lucide-react";

export function Hero() {
  return (
    <div className="relative w-full max-w-5xl mx-auto pt-24 pb-16 px-4 sm:px-6 lg:px-8 text-center overflow-hidden">
      
      {/* Decorative floating background elements */}
      <div className="absolute top-10 left-[10%] opacity-20 animate-float-slow text-primary">
        <Twitter size={64} />
      </div>
      <div className="absolute top-20 right-[15%] opacity-20 animate-float-medium text-emerald-500">
        <MessageCircleHeart size={48} />
      </div>
      <div className="absolute bottom-10 left-[20%] opacity-20 animate-float-fast text-rose-500">
        <Frown size={56} />
      </div>
      <div className="absolute bottom-24 right-[25%] opacity-20 animate-float-slow text-slate-400">
        <Meh size={40} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
        className="relative z-10 space-y-6"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-panel border-primary/20 text-primary mb-4">
          <Sparkles size={16} className="text-primary" />
          <span className="text-sm font-semibold tracking-wide uppercase">AI-Powered Sentiment Detection</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold text-foreground leading-tight">
          Understand the <br className="hidden md:block" />
          <span className="text-gradient">Feeling Behind</span> Every Tweet.
        </h1>
        
        <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
          Instantly decode the emotional tone of any text. Our advanced AI model analyzes context to classify sentiment with high-precision confidence scores.
        </p>
      </motion.div>
    </div>
  );
}
