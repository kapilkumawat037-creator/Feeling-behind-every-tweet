import { Hero } from "@/components/Hero";
import { Analyzer } from "@/components/Analyzer";
import { HistoryList } from "@/components/HistoryList";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="min-h-screen w-full overflow-x-hidden">
      {/* Background ambient lighting effects */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-500/5 blur-[120px]" />
      </div>

      <div className="relative z-10 flex flex-col items-center w-full">
        <Hero />
        
        <motion.div 
          className="w-full"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          <Analyzer />
        </motion.div>
        
        <HistoryList />
      </div>
      
      {/* Footer */}
      <footer className="relative z-10 w-full py-8 mt-auto border-t border-white/5 bg-background/50 backdrop-blur-md">
        <div className="max-w-5xl mx-auto px-4 text-center text-muted-foreground text-sm font-medium">
          <p>Emotion Analysis AI &copy; {new Date().getFullYear()}. All systems nominal.</p>
        </div>
      </footer>
    </div>
  );
}
