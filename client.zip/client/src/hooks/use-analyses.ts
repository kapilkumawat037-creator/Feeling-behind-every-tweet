import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { CreateAnalysisInput, AnalysisResponse, AnalysesListResponse } from "@shared/routes";
import { z } from "zod";

export function useAnalyses() {
  return useQuery({
    queryKey: [api.analyses.list.path],
    queryFn: async () => {
      const res = await fetch(api.analyses.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch analyses");
      const data = await res.json();
      
      // Parse with schema to ensure types are correct, handling dates correctly
      return api.analyses.list.responses[200].parse(
        data.map((item: any) => ({
          ...item,
          createdAt: new Date(item.createdAt) // Ensure dates are objects for frontend usage
        }))
      );
    },
  });
}

export function useCreateAnalysis() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (input: CreateAnalysisInput) => {
      const validated = api.analyses.create.input.parse(input);
      
      const res = await fetch(api.analyses.create.path, {
        method: api.analyses.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        let errorMessage = "Failed to analyze tweet";
        try {
          const errorData = await res.json();
          if (res.status === 400) {
            const parsedError = api.analyses.create.responses[400].parse(errorData);
            errorMessage = parsedError.message;
          }
        } catch (e) {
          // Fallback to generic error
        }
        throw new Error(errorMessage);
      }

      const data = await res.json();
      return {
        ...data,
        createdAt: new Date(data.createdAt)
      } as AnalysisResponse;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.analyses.list.path] });
      toast({
        title: "Analysis Complete",
        description: "Your text has been successfully analyzed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}
