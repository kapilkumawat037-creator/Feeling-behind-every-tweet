import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const analyses = pgTable("analyses", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  emotion: text("emotion").notNull(), // 'Positive', 'Negative', 'Neutral'
  confidenceScore: integer("confidence_score").notNull(), // 0 to 100
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertAnalysisSchema = createInsertSchema(analyses).omit({ 
  id: true, 
  createdAt: true 
});

export type Analysis = typeof analyses.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;

// API request/response types
export type CreateAnalysisRequest = {
  text: string;
};

export type AnalysisResponse = Analysis;
export type AnalysesListResponse = Analysis[];
